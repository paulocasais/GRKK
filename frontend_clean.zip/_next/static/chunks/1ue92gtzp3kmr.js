(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,31278,e=>{"use strict";let a=(0,e.i(75254).default)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);e.s(["Loader2",0,a],31278)},63488,e=>{"use strict";let a=(0,e.i(75254).default)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]]);e.s(["Mail",0,a],63488)},43432,e=>{"use strict";let a=(0,e.i(75254).default)("Phone",[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}]]);e.s(["Phone",0,a],43432)},95468,e=>{"use strict";let a=(0,e.i(75254).default)("CircleCheck",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);e.s(["CheckCircle2",0,a],95468)},84614,e=>{"use strict";let a=(0,e.i(75254).default)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]);e.s(["User",0,a],84614)},51737,e=>{"use strict";let a=(0,e.i(75254).default)("ShieldAlert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]);e.s(["ShieldAlert",0,a],51737)},55436,e=>{"use strict";let a=(0,e.i(75254).default)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);e.s(["Search",0,a],55436)},3281,e=>{"use strict";let a=(0,e.i(75254).default)("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]);e.s(["Printer",0,a],3281)},15829,e=>{"use strict";e.s(["CORES_FAIXAS",0,{Branca:{bg:"bg-white",border:"border-zinc-300",text:"text-zinc-800",progressClass:"bg-white border border-gray-300"},"Branca/Amarela":{bg:"bg-white",border:"border-yellow-450",text:"text-zinc-800",stripe:"bg-yellow-450",progressClass:"bg-gradient-to-r from-white to-yellow-400 border border-yellow-400"},Amarela:{bg:"bg-yellow-450",border:"border-yellow-600",text:"text-zinc-900",progressClass:"bg-yellow-400"},"Amarela/Laranja":{bg:"bg-yellow-450",border:"border-orange-500",text:"text-zinc-900",stripe:"bg-orange-500",progressClass:"bg-gradient-to-r from-yellow-400 to-orange-500"},Laranja:{bg:"bg-orange-500",border:"border-orange-700",text:"text-white",progressClass:"bg-orange-500"},"Laranja/Verde":{bg:"bg-orange-500",border:"border-emerald-600",text:"text-white",stripe:"bg-emerald-600",progressClass:"bg-gradient-to-r from-orange-500 to-emerald-700"},Verde:{bg:"bg-emerald-700",border:"border-emerald-900",text:"text-white",progressClass:"bg-emerald-600"},"Verde/Azul":{bg:"bg-teal-600",border:"border-teal-800",text:"text-white",stripe:"bg-blue-600",progressClass:"bg-gradient-to-r from-emerald-600 to-blue-600"},Azul:{bg:"bg-blue-600",border:"border-blue-800",text:"text-white",progressClass:"bg-blue-600"},"Azul/Vermelha":{bg:"bg-indigo-600",border:"border-indigo-800",text:"text-white",stripe:"bg-red-500",progressClass:"bg-gradient-to-r from-blue-600 to-red-500"},Vermelha:{bg:"bg-red-600",border:"border-red-800",text:"text-white",progressClass:"bg-red-500"},Marrom:{bg:"bg-amber-900",border:"border-amber-950",text:"text-white",progressClass:"bg-amber-800"},"Marrom I":{bg:"bg-amber-900",border:"border-amber-950",text:"text-white",stripe:"bg-white",progressClass:"bg-amber-900"},"Marrom II":{bg:"bg-amber-900",border:"border-amber-950",text:"text-white",stripe:"bg-amber-400",progressClass:"bg-amber-950"},"Preta I":{bg:"bg-zinc-950",border:"border-yellow-600",text:"text-gold",stripe:"bg-yellow-500",progressClass:"bg-zinc-900 border border-zinc-700"},"Preta II":{bg:"bg-zinc-950",border:"border-yellow-500",text:"text-gold",stripe:"bg-yellow-400",progressClass:"bg-zinc-950 border border-gold/40"}},"FAIXAS",0,["Branca","Branca/Amarela","Amarela","Amarela/Laranja","Laranja","Laranja/Verde","Verde","Verde/Azul","Azul","Azul/Vermelha","Vermelha","Marrom","Marrom I","Marrom II","Preta I","Preta II"],"FAIXAS_ADULTO",0,["Amarela","Laranja","Verde","Azul","Vermelha","Marrom","Marrom I","Marrom II","Preta I","Preta II"],"FAIXAS_INFANTIL",0,["Branca/Amarela","Amarela","Amarela/Laranja","Laranja","Laranja/Verde","Verde","Verde/Azul","Azul","Azul/Vermelha","Vermelha","Marrom","Marrom I","Marrom II"]])},51004,e=>{"use strict";var a=e.i(43476),s=e.i(71645),t=e.i(32341),r=e.i(51737),i=e.i(31278),l=e.i(55436),n=e.i(95468),o=e.i(84614),d=e.i(64030),c=e.i(63488),x=e.i(43432),p=e.i(3281),m=e.i(15829);let b="https://api.gojuryukaratekai.com.br";function u(e){let s=m.CORES_FAIXAS[e]||{bg:"bg-zinc-800",border:"border-zinc-700",text:"text-white"};return(0,a.jsxs)("div",{className:`relative flex items-center justify-between px-2.5 py-1 rounded border text-[9px] font-black uppercase tracking-wider ${s.bg} ${s.border} ${s.text} shadow-sm overflow-hidden h-[22px] w-[95px] select-none`,children:[(0,a.jsx)("span",{className:"truncate pr-1",children:e}),s.stripe?(0,a.jsx)("div",{className:`absolute right-0 top-0 bottom-0 w-2.5 ${s.stripe}`,title:"Ponteira de Graduação"}):(0,a.jsx)("div",{className:"absolute right-0 top-0 bottom-0 w-1 bg-zinc-950/20"})]})}e.s(["default",0,function(){let{usuario:e,tipo:g,isAdmin:h}=(0,t.useAuth)(),[f,v]=(0,s.useState)([]),[j,w]=(0,s.useState)(!0),[N,z]=(0,s.useState)(""),[y,C]=(0,s.useState)("todos"),[k,A]=(0,s.useState)([]),[$,_]=(0,s.useState)(null),[F,S]=(0,s.useState)(null),[I,M]=(0,s.useState)(""),[D,P]=(0,s.useState)(""),[L,E]=(0,s.useState)(!1),R=async()=>{try{let e=await fetch(`${b}/api/atletas`,{credentials:"include"});if(!e.ok)throw Error("Falha ao obter atletas da API");let a=await e.json();v(a.atletas||[])}catch(e){console.error("Erro ao carregar atletas, usando dados emulados:",e),v([{id:"st-1",nome:"Pedro Oliveira",email:"pedro.oliveira@grkk.com.br",telefone:"(71) 98888-2001",faixa:"Branca",status:"ativo",filial_nome:"Filial Salvador Centro"},{id:"st-2",nome:"Lucas Almeida",email:"lucas.almeida@grkk.com.br",telefone:"(71) 98888-2002",faixa:"Amarela",status:"ativo",filial_nome:"Filial Salvador Centro"},{id:"pending-athlete-id",nome:"Atleta Pendente de Teste",email:"atleta-pendente@grkk.com.br",telefone:"71988888888",faixa:"Branca",status:"pendente",filial_nome:"GRKK CABULA"}])}finally{w(!1)}},T=async()=>{try{let e=await fetch(`${b}/api/filiais`,{credentials:"include"});if(e.ok){let a=await e.json();A(a.filiais||[])}}catch(e){console.error("Erro ao carregar filiais na área administrativa:",e)}};(0,s.useEffect)(()=>{R(),T()},[]);let V=async(e,a)=>{try{if(!(await fetch(`${b}/api/atletas/${e}`,{method:"PATCH",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({status:a})})).ok)throw Error("Erro ao alterar status do atleta");v(f.map(s=>s.id===e?{...s,status:a}:s))}catch(s){v(f.map(s=>s.id===e?{...s,status:a}:s))}},B=async e=>{if(confirm("Tem certeza que deseja excluir permanentemente este atleta?"))try{if(!(await fetch(`${b}/api/atletas/${e}`,{method:"DELETE",credentials:"include"})).ok)throw Error("Erro ao excluir atleta");v(f.filter(a=>a.id!==e))}catch(a){v(f.filter(a=>a.id!==e))}},O=async e=>{if(e.preventDefault(),$){E(!0);try{let e=k.find(e=>e.id===D),a=e?e.nome:"Dojo Central / Sem Filial";(await fetch(`${b}/api/atletas/${$.id}`,{method:"PATCH",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({faixa:I,filial_id:D||null,filial_nome:D?a:null})})).ok&&(v(f.map(e=>e.id===$.id?{...e,faixa:I,filial_id:D||void 0,filial_nome:D?a:"Dojo Central / Sem Filial"}:e)),_(null))}catch(s){let e=k.find(e=>e.id===D),a=e?e.nome:"Dojo Central / Sem Filial";v(f.map(e=>e.id===$.id?{...e,faixa:I,filial_id:D||void 0,filial_nome:D?a:"Dojo Central / Sem Filial"}:e)),_(null)}finally{E(!1)}}},G=f.filter(e=>{let a=e.nome.toLowerCase().includes(N.toLowerCase())||e.email.toLowerCase().includes(N.toLowerCase()),s="todos"===y||e.status===y;return a&&s});return j?(0,a.jsx)("div",{className:"flex items-center justify-center min-h-[70vh]",children:(0,a.jsx)(i.Loader2,{className:"w-8 h-8 text-primary animate-spin"})}):"admin"!==g&&"filial"!==g?(0,a.jsxs)("div",{className:"flex flex-col items-center justify-center min-h-[60vh] text-center space-y-4",children:[(0,a.jsx)(r.ShieldAlert,{className:"w-16 h-16 text-red-500"}),(0,a.jsx)("h2",{className:"text-xl font-bold text-white font-cinzel",children:"Acesso Negado"}),(0,a.jsx)("p",{className:"text-zinc-500 text-sm",children:"Apenas administradores e filiais homologadas podem acessar este painel."})]}):(0,a.jsxs)("main",{className:"p-4 sm:p-6 lg:p-8 xl:p-10 space-y-8 w-full max-w-7xl mx-auto",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("h1",{className:"text-2xl font-black text-white font-cinzel tracking-wider",children:"Gestão de Atletas"}),(0,a.jsx)("p",{className:"text-xs text-zinc-500 mt-0.5 uppercase tracking-widest font-semibold",children:"Homologação de cadastros e graduações"})]}),(0,a.jsxs)("div",{className:"flex flex-col md:flex-row items-center justify-between gap-4",children:[(0,a.jsx)("div",{className:"flex items-center gap-1.5 bg-zinc-900 p-1 border border-zinc-800 rounded-xl w-full md:w-auto",children:["todos","ativo","pendente"].map(e=>(0,a.jsx)("button",{onClick:()=>C(e),className:`flex-1 md:flex-none px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition cursor-pointer ${y===e?"bg-primary text-white":"text-zinc-500 hover:text-white"}`,children:"todos"===e?"Todos":"ativo"===e?"Ativos":"Pendentes"},e))}),(0,a.jsxs)("div",{className:"relative w-full md:max-w-xs",children:[(0,a.jsx)("input",{type:"text",placeholder:"Buscar por nome ou e-mail...",value:N,onChange:e=>z(e.target.value),className:"w-full pl-9 pr-4 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl text-white outline-none"}),(0,a.jsx)(l.Search,{size:14,className:"absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500"})]})]}),(0,a.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",children:[G.map(e=>(0,a.jsxs)("div",{className:"bg-zinc-900 border border-zinc-800/80 rounded-2xl p-5 space-y-4 flex flex-col justify-between",children:[(0,a.jsxs)("div",{className:"space-y-3",children:[(0,a.jsxs)("div",{className:"flex items-start justify-between",children:[(0,a.jsxs)("div",{className:"flex items-center gap-3",children:[(0,a.jsx)("div",{className:"w-10 h-10 bg-zinc-950 border border-zinc-850 rounded-xl flex items-center justify-center text-zinc-400",children:(0,a.jsx)(o.User,{size:18})}),(0,a.jsxs)("div",{children:[(0,a.jsx)("h3",{className:"text-sm font-bold text-white leading-tight",children:e.nome}),(0,a.jsx)("p",{className:"text-[10px] text-zinc-500",children:e.filial_nome||"Dojo Central"})]})]}),(0,a.jsx)("span",{className:`px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider rounded-md border ${"ativo"===e.status?"bg-emerald-500/10 text-emerald-400 border-emerald-500/20":"pendente"===e.status?"bg-amber-500/10 text-amber-400 border-amber-500/20":"bg-red-500/10 text-red-400 border-red-500/20"}`,children:e.status})]}),(0,a.jsxs)("div",{className:"space-y-1.5 pt-2 border-t border-zinc-800/50",children:[(0,a.jsxs)("p",{className:"text-[10px] text-zinc-400 flex items-center gap-1.5 font-mono",children:[(0,a.jsx)(c.Mail,{size:11,className:"text-zinc-650"})," ",e.email]}),(0,a.jsxs)("p",{className:"text-[10px] text-zinc-400 flex items-center gap-1.5 font-mono",children:[(0,a.jsx)(x.Phone,{size:11,className:"text-zinc-650"})," ",e.telefone||"Não informado"]}),(0,a.jsxs)("div",{className:"text-[10px] text-zinc-400 flex items-center justify-between gap-1.5 pt-1 border-t border-zinc-800/10",children:[(0,a.jsxs)("span",{className:"flex items-center gap-1.5 font-mono",children:[(0,a.jsx)(d.Trophy,{size:11,className:"text-zinc-650"})," Graduação:"]}),u(e.faixa)]})]})]}),(0,a.jsxs)("div",{className:"flex flex-col gap-2 pt-4 border-t border-zinc-800/40",children:["pendente"===e.status&&(0,a.jsxs)("div",{className:"flex gap-2",children:[(0,a.jsxs)("button",{onClick:()=>V(e.id,"ativo"),className:"flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-1.5",children:[(0,a.jsx)(n.CheckCircle2,{size:12})," Homologar"]}),(0,a.jsx)("button",{onClick:()=>V(e.id,"inativo"),className:"flex-1 py-2 bg-zinc-950 hover:bg-red-950/40 border border-zinc-800 hover:border-red-900/30 text-zinc-400 hover:text-red-400 rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-1.5",children:"Negar"})]}),"ativo"===e.status&&(0,a.jsx)("button",{onClick:()=>V(e.id,"inativo"),className:"w-full py-2 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer text-center",children:"Suspender Atleta"}),"inativo"===e.status&&(0,a.jsx)("button",{onClick:()=>V(e.id,"ativo"),className:"w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer text-center flex items-center justify-center gap-1",children:"Re-homologar"}),(0,a.jsxs)("div",{className:"flex gap-2",children:[(0,a.jsx)("button",{onClick:()=>S(e),className:"flex-1 py-2 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer text-center",children:"Ver Ficha"}),(0,a.jsx)("button",{onClick:()=>{_(e),M(e.faixa),P(e.filial_id||"")},className:"flex-1 py-2 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer text-center",children:"Faixa / Dojo"})]}),(0,a.jsx)("button",{onClick:()=>B(e.id),className:"w-full py-1.5 bg-red-950/20 hover:bg-red-650 border border-red-900/20 hover:border-red-500 text-red-400 hover:text-white rounded-xl text-[9px] font-bold uppercase tracking-wider transition cursor-pointer text-center",children:"Excluir Atleta"})]})]},e.id)),0===G.length&&(0,a.jsx)("div",{className:"col-span-full py-12 text-center text-zinc-500 text-xs",children:"Nenhum atleta encontrado."})]}),$&&(0,a.jsx)("div",{className:"fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4",children:(0,a.jsxs)("div",{className:"bg-zinc-900 border border-zinc-850 rounded-2xl w-full max-w-sm p-6 relative",children:[(0,a.jsx)("h3",{className:"text-base font-bold text-white font-cinzel mb-1",children:"Dados Técnicos do Atleta"}),(0,a.jsxs)("p",{className:"text-[10px] text-zinc-400 uppercase tracking-wider mb-5",children:["Atleta: ",(0,a.jsx)("strong",{className:"text-white",children:$.nome})]}),(0,a.jsxs)("form",{onSubmit:O,className:"space-y-4",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"block text-[10px] font-bold text-zinc-450 uppercase mb-1.5",children:"Faixa / Graduação"}),(0,a.jsxs)("select",{value:I,onChange:e=>M(e.target.value),className:"w-full px-3.5 py-2.5 text-xs bg-zinc-950 border border-zinc-800 rounded-xl text-white outline-none focus:border-gold",children:[(0,a.jsx)("optgroup",{label:"── Divisão Infantil ──",children:m.FAIXAS_INFANTIL.map(e=>(0,a.jsx)("option",{value:e,children:e},`inf-${e}`))}),(0,a.jsx)("optgroup",{label:"── Divisão Adulto ──",children:m.FAIXAS_ADULTO.map(e=>(0,a.jsx)("option",{value:e,children:e},`adu-${e}`))})]})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"block text-[10px] font-bold text-zinc-450 uppercase mb-1.5",children:"Dojo / Filial"}),(0,a.jsxs)("select",{value:D,onChange:e=>P(e.target.value),className:"w-full px-3.5 py-2.5 text-xs bg-zinc-950 border border-zinc-800 rounded-xl text-white outline-none focus:border-gold",children:[(0,a.jsx)("option",{value:"",children:"Dojo Central (Nenhuma Filial)"}),k.map(e=>(0,a.jsx)("option",{value:e.id,children:e.nome},e.id))]})]}),(0,a.jsxs)("div",{className:"flex gap-2.5 pt-2",children:[(0,a.jsx)("button",{type:"button",onClick:()=>_(null),className:"flex-1 py-2.5 bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition cursor-pointer",children:"Cancelar"}),(0,a.jsx)("button",{type:"submit",disabled:L,className:"flex-1 py-2.5 bg-gradient-to-r from-red-600 to-red-800 text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition hover:scale-[1.02] cursor-pointer flex items-center justify-center",children:L?(0,a.jsx)(i.Loader2,{size:12,className:"animate-spin"}):"Confirmar"})]})]})]})}),F&&(0,a.jsx)("div",{className:"fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4",children:(0,a.jsxs)("div",{className:"bg-zinc-950 border border-zinc-900 rounded-3xl w-full max-w-2xl p-6 sm:p-8 space-y-6 relative overflow-hidden animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto",children:[(0,a.jsx)("div",{className:"absolute -top-12 -right-12 w-32 h-32 bg-primary/5 rounded-full blur-2xl pointer-events-none"}),(0,a.jsxs)("div",{className:"flex justify-between items-start border-b border-zinc-900 pb-4",children:[(0,a.jsxs)("div",{children:[(0,a.jsxs)("div",{className:"flex flex-col sm:flex-row sm:items-center gap-3",children:[(0,a.jsx)("h3",{className:"text-xl font-bold text-white font-cinzel tracking-wider",children:F.nome}),u(F.faixa)]}),(0,a.jsx)("p",{className:"text-[10px] text-zinc-500 uppercase tracking-widest font-semibold mt-1",children:"Ficha Cadastral e Ficha Médica"})]}),(0,a.jsx)("button",{onClick:()=>S(null),className:"w-8 h-8 rounded-xl bg-zinc-900/50 flex items-center justify-center text-zinc-400 hover:text-white border border-zinc-800/80 hover:border-zinc-700 transition cursor-pointer",children:"×"})]}),(0,a.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[(0,a.jsxs)("div",{className:"space-y-4",children:[(0,a.jsx)("h4",{className:"text-xs font-bold text-gold font-cinzel tracking-wider uppercase",children:"Dados Pessoais e Contato"}),(0,a.jsxs)("div",{className:"space-y-2.5 text-xs",children:[(0,a.jsxs)("p",{className:"text-zinc-400",children:["CPF: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.cpf?F.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/,"$1.$2.$3-$4"):"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Data de Nascimento: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.data_nascimento?F.data_nascimento.split("-").reverse().join("/"):"Não informada"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Idade: ",(0,a.jsxs)("strong",{className:"text-white",children:[F.data_nascimento?new Date().getFullYear()-new Date(F.data_nascimento).getFullYear():"—"," anos"]})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Sexo: ",(0,a.jsx)("strong",{className:"text-white",children:"M"===F.sexo?"Masculino":"F"===F.sexo?"Feminino":"Outro"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Celular: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.telefone||"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["E-mail: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.email})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Dojo / Filial: ",(0,a.jsx)("strong",{className:"text-white",children:F.filial_nome||"Dojo Central"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Professor / Sensei: ",(0,a.jsx)("strong",{className:"text-white",children:F.nome_professor||"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Endereço: ",(0,a.jsxs)("strong",{className:"text-white leading-relaxed",children:[F.endereco||"Não cadastrado"," ",F.cidade?`, ${F.cidade} - ${F.uf||"BA"}`:""]})]})]})]}),(0,a.jsxs)("div",{className:"space-y-6",children:[F.data_nascimento&&new Date().getFullYear()-new Date(F.data_nascimento).getFullYear()<18?(0,a.jsxs)("div",{className:"bg-zinc-900/40 border border-gold/15 rounded-2xl p-4 space-y-3",children:[(0,a.jsx)("h4",{className:"text-[11px] font-bold text-gold font-cinzel tracking-wider uppercase",children:"Responsável Legal (Menor)"}),(0,a.jsxs)("div",{className:"space-y-2 text-xs",children:[(0,a.jsxs)("p",{className:"text-zinc-400",children:["Nome: ",(0,a.jsx)("strong",{className:"text-white",children:F.responsavel_nome||"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["CPF: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.responsavel_cpf?F.responsavel_cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/,"$1.$2.$3-$4"):"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["Celular: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.responsavel_telefone||"Não informado"})]}),(0,a.jsxs)("p",{className:"text-zinc-400",children:["E-mail: ",(0,a.jsx)("strong",{className:"text-white font-mono",children:F.responsavel_email||"Não informado"})]})]})]}):null,(0,a.jsxs)("div",{className:"space-y-4",children:[(0,a.jsx)("h4",{className:"text-xs font-bold text-emerald-400 font-cinzel tracking-wider uppercase",children:"Ficha Médica do Atleta"}),(0,a.jsxs)("div",{className:"space-y-3.5 text-xs",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Alergias"}),(0,a.jsx)("p",{className:"text-white leading-relaxed bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:F.medico_alergias||"Nenhuma alergia relatada."})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Plano de Saúde"}),(0,a.jsx)("p",{className:"text-white bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:F.medico_plano||"Sem informações de convênio médico."})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Restrições Físicas / Médicas"}),(0,a.jsx)("p",{className:"text-white leading-relaxed bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:F.medico_restricoes||"Nenhuma restrição relatada."})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("p",{className:"text-zinc-500 font-bold uppercase text-[9px] mb-1",children:"Diagnósticos Clínicos"}),(0,a.jsx)("p",{className:"text-white leading-relaxed bg-zinc-950 p-2.5 border border-zinc-900 rounded-xl",children:F.medico_diagnosticos||"Nenhum diagnóstico clínico relatado."})]})]})]})]})]}),(0,a.jsxs)("div",{className:"flex justify-end gap-3 pt-4 border-t border-zinc-900",children:[(0,a.jsxs)("button",{onClick:()=>{let e,a,s,t,r,i;return e=F.data_nascimento?F.data_nascimento.split("-").reverse().join("/"):"Não informada",a=F.cpf?F.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/,"$1.$2.$3-$4"):"Não informado",s=F.data_nascimento?new Date().getFullYear()-new Date(F.data_nascimento).getFullYear():"—",t=F.data_nascimento&&new Date().getFullYear()-new Date(F.data_nascimento).getFullYear()<18,r=F.responsavel_cpf?F.responsavel_cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/,"$1.$2.$3-$4"):"Não informado",void((i=window.open("","_blank"))&&(i.document.write(`
      <html>
      <head>
        <title>Ficha Cadastral e M\xe9dica - ${F.nome}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Inter:wght@400;600;800&display=swap');
          body {
            font-family: 'Inter', sans-serif;
            color: #111;
            background-color: #fff;
            padding: 30px;
            font-size: 11px;
            line-height: 1.4;
          }
          .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 12px;
            margin-bottom: 20px;
          }
          .header h1 {
            font-family: 'Cinzel', serif;
            font-size: 18px;
            margin: 0 0 4px 0;
            letter-spacing: 2px;
            text-transform: uppercase;
          }
          .header p {
            font-size: 9px;
            margin: 0;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: #555;
          }
          .section-title {
            font-family: 'Cinzel', serif;
            font-size: 11px;
            font-weight: bold;
            border-bottom: 1px solid #111;
            padding-bottom: 3px;
            margin-top: 20px;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
          }
          .grid-3 {
            grid-template-columns: repeat(3, 1fr);
          }
          .grid-full {
            grid-column: span 2;
          }
          .grid-full-3 {
            grid-column: span 3;
          }
          .field {
            display: flex;
            flex-direction: column;
          }
          .label {
            font-size: 8px;
            font-weight: 800;
            text-transform: uppercase;
            color: #666;
            margin-bottom: 3px;
          }
          .value {
            font-size: 11px;
            font-weight: 600;
            color: #000;
            padding: 6px 10px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            min-height: 14px;
          }
          .value-large {
            min-height: 40px;
          }
          .signature-area {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
            gap: 30px;
          }
          .signature-box {
            flex: 1;
            text-align: center;
          }
          .signature-line {
            border-top: 1px solid #111;
            margin-top: 35px;
            padding-top: 5px;
            font-size: 8px;
            font-weight: 600;
            text-transform: uppercase;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Associa\xe7\xe3o Goju-Ryu Karate Kai</h1>
          <p>Ficha de Matr\xedcula & Ficha M\xe9dica de Emerg\xeancia</p>
        </div>

        <div class="section-title">Dados Gerais e T\xe9cnicos</div>
        <div class="grid grid-3">
          <div class="field grid-full-3">
            <span class="label">Nome Completo</span>
            <span class="value">${F.nome}</span>
          </div>
          <div class="field">
            <span class="label">Gradua\xe7\xe3o Atual</span>
            <span class="value">${F.faixa}</span>
          </div>
          <div class="field">
            <span class="label">Dojo / Filial</span>
            <span class="value">${F.filial_nome||"Dojo Central"}</span>
          </div>
          <div class="field">
            <span class="label">Professor Respons\xe1vel</span>
            <span class="value">${F.nome_professor||"Não informado"}</span>
          </div>
        </div>

        <div class="section-title">Informa\xe7\xf5es Pessoais</div>
        <div class="grid">
          <div class="field">
            <span class="label">CPF</span>
            <span class="value">${a}</span>
          </div>
          <div class="field">
            <span class="label">Data de Nascimento</span>
            <span class="value">${e} (Idade: ${s} anos)</span>
          </div>
          <div class="field">
            <span class="label">Sexo</span>
            <span class="value">${"M"===F.sexo?"Masculino":"F"===F.sexo?"Feminino":"Outro"}</span>
          </div>
          <div class="field">
            <span class="label">Celular</span>
            <span class="value">${F.telefone||"Não informado"}</span>
          </div>
          <div class="field grid-full">
            <span class="label">E-mail</span>
            <span class="value">${F.email}</span>
          </div>
          <div class="field grid-full">
            <span class="label">Endere\xe7o Residencial</span>
            <span class="value">${F.endereco||"Não cadastrado"} ${F.cidade?`, ${F.cidade} - ${F.uf||"BA"}`:""}</span>
          </div>
        </div>

        ${t?`
        <div class="section-title">Respons\xe1vel Legal (Menor de 18 Anos)</div>
        <div class="grid">
          <div class="field grid-full">
            <span class="label">Nome do Respons\xe1vel</span>
            <span class="value">${F.responsavel_nome||"Não informado"}</span>
          </div>
          <div class="field">
            <span class="label">CPF do Respons\xe1vel</span>
            <span class="value">${r}</span>
          </div>
          <div class="field">
            <span class="label">Celular do Respons\xe1vel</span>
            <span class="value">${F.responsavel_telefone||"Não informado"}</span>
          </div>
          <div class="field grid-full">
            <span class="label">E-mail do Respons\xe1vel</span>
            <span class="value">${F.responsavel_email||"Não informado"}</span>
          </div>
        </div>
        `:""}

        <div class="section-title">Ficha M\xe9dica & Restri\xe7\xf5es</div>
        <div class="grid">
          <div class="field grid-full">
            <span class="label">Alergias Alimentares / Medicamentosas</span>
            <span class="value value-large">${F.medico_alergias||"Nenhuma alergia relatada."}</span>
          </div>
          <div class="field grid-full">
            <span class="label">Plano de Sa\xfade / Conv\xeanio</span>
            <span class="value">${F.medico_plano||"Sem informações de convênio médico."}</span>
          </div>
          <div class="field grid-full">
            <span class="label">Restri\xe7\xf5es F\xedsicas / Recomenda\xe7\xf5es M\xe9dicas</span>
            <span class="value value-large">${F.medico_restricoes||"Nenhuma restrição física relatada."}</span>
          </div>
          <div class="field grid-full">
            <span class="label">Diagn\xf3sticos Cl\xednicos / Patologias</span>
            <span class="value value-large">${F.medico_diagnosticos||"Nenhum diagnóstico relatado."}</span>
          </div>
        </div>

        <div class="signature-area">
          <div class="signature-box">
            <div class="signature-line">Assinatura do Atleta (ou Respons\xe1vel Legal)</div>
          </div>
          <div class="signature-box">
            <div class="signature-line">Assinatura do Sensei Respons\xe1vel</div>
          </div>
        </div>
      </body>
      </html>
    `),i.document.close(),i.focus(),setTimeout(()=>{i.print(),i.close()},500)))},className:"px-5 py-2.5 bg-gold hover:bg-gold-dark text-white rounded-xl text-xs font-bold uppercase tracking-wider font-cinzel transition cursor-pointer flex items-center gap-1.5 shadow-lg shadow-gold/10",children:[(0,a.jsx)(p.Printer,{size:13}),"Imprimir Ficha"]}),(0,a.jsx)("button",{onClick:()=>S(null),className:"px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white rounded-xl text-xs font-bold uppercase tracking-wider font-cinzel transition cursor-pointer",children:"Fechar Ficha"})]})]})})]})}])}]);